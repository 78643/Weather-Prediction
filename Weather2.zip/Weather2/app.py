import warnings
warnings.filterwarnings('ignore')

from flask import Flask, request, render_template
import joblib
import numpy as np
from sklearn.preprocessing import StandardScaler

# Load the model and scaler
model = joblib.load('random_forest_weather_model.joblib')  # Model file
scaler = joblib.load('scaler.joblib')  # Scaler file

app = Flask(__name__)

# Mapping predictions to weather labels and CSS classes
weather_dict = {
    0: ('Drizzle', 'result-info'),
    1: ('Fog', 'result-warning'),
    2: ('Rain', 'result-danger'),
    3: ('Snow', 'result-warnings'),
    4: ('Sun', 'result-success')
}

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Extract input values
        temp_min = float(request.form['temp_min'])
        temp_max = float(request.form['temp_max'])
        wind = float(request.form['wind'])
        precipitation = float(request.form['precipitation'])

        # Feature engineering
        input_features = [
            temp_min,
            temp_max,
            wind,
            precipitation,
            temp_max - temp_min,
            wind ** 2,
            np.log1p(precipitation)
        ]

        # Scale input
        input_data = scaler.transform([input_features])

        # Predict
        prediction = model.predict(input_data)[0]
        predicted_weather, css_class = weather_dict.get(prediction, ('Unknown', 'result-info'))

        return render_template(
            'index.html',
            prediction_text=f'The predicted weather is: {predicted_weather}',
            prediction_class=css_class
        )

    except Exception as e:
        print("Prediction error:", e)
        return render_template(
            'index.html',
            prediction_text='Error in input values. Please check and try again.',
            prediction_class='result-danger'
        )

if __name__ == '__main__':
    app.run(debug=True)
